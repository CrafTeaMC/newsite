tag @s remove spectate
spreadplayers 9 8 20 20 true @e[limit=1,tag=spawnmarker]
tp @s @e[limit=1,tag=spawnmarker]
execute as @e[limit=1,tag=spawnmarker] at @s run tp @a[distance=..1] ~ ~-10 ~ ~ 90
gamemode adventure @s
effect clear @s minecraft:blindness