#--Sayac Ayarlama--#

execute if score .basladi anaskor matches 1 run scoreboard players operation .sdakika anaskor = .scustomdakika anaskor
execute if score .basladi anaskor matches 1 run scoreboard players set .stick anaskor 59
execute if score .basladi anaskor matches 1.. run scoreboard players add .stick anaskor 1
execute if score .basladi anaskor matches 1 run scoreboard players set .basladi anaskor 2
execute if score .basladi anaskor matches 1.. run execute if score .stick anaskor matches 20.. run scoreboard players remove .ssaniye anaskor 1
execute if score .basladi anaskor matches 1.. run execute if score .stick anaskor matches 20.. run scoreboard players set .stick anaskor 0
execute if score .basladi anaskor matches 1.. run execute if score .ssaniye anaskor matches ..0 run scoreboard players remove .sdakika anaskor 1
execute if score .basladi anaskor matches 1.. run execute if score .ssaniye anaskor matches ..0 run scoreboard players set .ssaniye anaskor 59


#-- Süre Bitiş--#
execute if score .basladi anaskor matches 1.. run execute if score .sdakika anaskor matches ..-1 run scoreboard players set .bitis anaskor 1
execute if score .basladi anaskor matches 1.. run execute if score .sdakika anaskor matches ..-1 run scoreboard players set .basladi anaskor 0
execute if score .bitis anaskor matches 1 run function data:paintball_bitis

#-- Sayacı Karşıya Yazdırma --#
execute as @e[tag=suretext] at @s run data merge entity @s {transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[25f,25f,25f]},text:'[{"text":"⏰ ","color":"gold","bold":true},{"score":{"name":".sdakika","objective":"anaskor"},"color":"green","bold":true},{"text":":","color":"green","bold":true},{"score":{"name":".ssaniye","objective":"anaskor"},"color":"green","bold":true}]',background:16711680}


#-- İtem Atma Engelleme --#
execute as @e[type=item] at @s on origin run data modify entity @e[type=item,sort=nearest,limit=1] Owner set from entity @s UUID
execute as @e[type=item] run data modify entity @s PickupDelay set value 0s
execute as @e[type=item] at @s on origin run tp @e[type=item,sort=nearest,limit=1] @s



# PAİNTBALL
execute as @a[nbt={Inventory:[{id:"minecraft:crossbow",tag:{paintSilah:1b,Charged:0b,CustomModelData:1}}]}] at @s run scoreboard players add @s[scores={cekissayac=0..10}] cekissayac 1
execute as @a[scores={cekissayac=11..},nbt={SelectedItem:{id:"minecraft:crossbow",tag:{paintSilah:1b,CustomModelData:1}}}] at @s run function data:susilahimermiyukle
scoreboard players set @a[nbt=!{Inventory:[{id:"minecraft:crossbow",tag:{paintSilah:1b,Charged:0b,CustomModelData:1}}]}] cekissayac 0
execute as @e[type=minecraft:arrow] at @s on origin if entity @s[nbt={SelectedItem:{id:"minecraft:crossbow",Count:1b,tag:{paintSilah:1b,CustomModelData:1}}}] run tag @e[type=minecraft:arrow,distance=..0.5] add smermi
execute as @e[tag=smermi,type=minecraft:arrow,nbt={inGround:true}] at @s run particle falling_lava ~ ~ ~ 1 1 1 1 100 force @a
execute as @e[tag=smermi,type=minecraft:arrow,nbt={inGround:true}] at @s on passengers run kill @s 
execute as @e[tag=smermi,type=minecraft:arrow,nbt={inGround:true}] at @s run kill @s
execute as @e[tag=smermi] at @s unless entity @e[tag=mermimarker,distance=..1] run summon minecraft:marker ~ ~ ~ {Tags:["mermimarker"]}
execute as @e[tag=smermi,nbt=!{Passengers:[{id:"minecraft:marker",Tags:["mermimarker"]}]}] at @s run ride @e[limit=1,distance=..1,type=minecraft:marker,tag=mermimarker] mount @s
execute as @e[tag=smermi] at @s store result score @s mermiid on origin run scoreboard players get @s id
execute as @e[tag=mermimarker] at @s store result score @s mermiid on vehicle run scoreboard players get @s mermiid
execute as @e[tag=mermimarker] at @s unless entity @e[tag=smermi,distance=..1] run function data:mermihasarver
execute as @e[tag=smermi] at @s run particle dust 0.84 0.15 0.04 1 ~ ~-0.1 ~ 0.1 0.1 0.1 0 20 force @a





#-- En Çok Ölen --#
execute as @a run scoreboard players operation .olumtavan olum > @s olum
execute as @a if score @s olum >= .olumtavan olum run tag @a[tag=encokolen] remove encokolen
execute as @a if score @s olum >= .olumtavan olum run tag @s add encokolen


#--Öldürme --#
execute as @a[scores={oldurme2=1..}] at @s unless score .barguncelle anaskor matches 1.. store result score .barguncelle anaskor run function data:bossbar/barguncelle1
execute as @a[scores={oldurme2=1..}] at @s run function data:oldurme/oldurdu
#-- Ölünce Ne olacak? --#
execute as @e[scores={olum2=1..}] at @s unless score .barguncelle anaskor matches 1.. store result score .barguncelle anaskor run function data:bossbar/barguncelle1
execute as @a[scores={olum2=1..}] at @s if score .basladi anaskor matches 1.. run tag @s add spectate
execute as @a[scores={olum2=1..}] at @s if score .basladi anaskor matches 1.. run function data:olum
execute as @e[scores={olum2=1..}] at @s run function data:ruh/depola
execute as @e[scores={olum2=1..}] at @s run scoreboard players set @s olum2 0
execute as @e[tag=spectate] at @s run scoreboard players add @s stick 1
execute as @e[tag=spectate,scores={stick=20..}] at @s run scoreboard players remove @s ssaniye 1
execute as @e[tag=spectate,scores={stick=20..}] at @s run scoreboard players set @s stick 0
execute as @a[tag=spectate] at @s run title @s actionbar [    "",    {        "color": "dark_red",        "translate": "dogma.son","fallback":"You'll be respawned in a moment. "    },    {        "text": " "    },    {        "color": "dark_green",        "score": {            "name": "@s",            "objective": "ssaniye"        }    }]
execute as @e[tag=spectate,scores={ssaniye=..0}] at @s run function data:dogum
execute as @e[nbt={Inventory:[{tag:{oyunzirh:1b},Slot:-106b}]}] at @s run item replace entity @s weapon.offhand with air




# Her Oyuncuya Özel Bossbar

execute as @a at @s unless score @s barolustu matches 1.. unless score .barolusturuyor anaskor matches 1.. store result score .barolusturuyor anaskor run function data:bossbar/barolustur


# uçuran fişek 
execute as @e[type=minecraft:firework_rocket] at @s run ride @e[limit=1,type=minecraft:player,distance=..1] mount @s

# dolap
execute unless score .basladi anaskor matches 1.. run function data:dolap/tick



# loot
execute as @e[tag=lootvarilmarker] at @s run particle minecraft:happy_villager ~ ~0.5 ~ 0.5 0.5 0.5 1 3 force @a
execute as @e[tag=lootvarilmarker] at @s if block ~ ~-0.2 ~ air run tp @s ~ ~-0.2 ~
execute as @e[tag=lootvarilmarker] at @s unless block ~ ~-0.2 ~ air run function data:loot/dustu
execute as @e[tag=lootitem] at @s run particle minecraft:scrape ~ ~ ~ 0.5 0.5 0.5 1 1 force @a


# flaş bombası
execute as @e[type=minecraft:snowball] at @s unless score @s fbomba matches 1.. run function data:loot/fbomba
execute as @e[tag=fbomba] at @s unless entity @e[type=minecraft:snowball,distance=..1] unless score @s fbomba matches 1.. run playsound minecraft:block.glass.break master @a ~ ~ ~ 2 1
execute as @e[tag=fbomba] at @s unless entity @e[type=minecraft:snowball,distance=..1] unless score @s fbomba matches 1.. store success score @s fbomba run data merge entity @s {Duration:120}
execute as @e[tag=fbomba] at @s unless entity @e[type=minecraft:snowball,distance=..1] run particle minecraft:flash ~ ~ ~ 1 1 1 1 10 force @a
execute as @e[tag=fbomba] at @s unless entity @e[type=minecraft:snowball,distance=..1] run effect give @a[distance=..3] minecraft:blindness 5 255 true
execute as @e[tag=fbomba] at @s unless entity @e[type=minecraft:snowball,distance=..1] run playsound minecraft:block.note_block.bell master @a[distance=..3] ~ ~ ~ 100 2

# el bombası
execute as @e[type=minecraft:egg] at @s unless score @s ebomba matches 1.. run function data:loot/ebomba
execute as @e[tag=ebomba] at @s unless entity @e[type=minecraft:egg,distance=..1] run function data:loot/epatlat

# bandaj
execute as @a[scores={endergoz=1..}] at @s run function data:loot/bandaj

# ölüm can
execute as @e[tag=olumkalp] at @s if entity @a[distance=..1] run playsound minecraft:block.decorated_pot.insert master @a[distance=..1] ~ ~ ~ 100 0
execute as @e[tag=olumkalp] at @s if entity @a[distance=..1] run particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 1 5 force @a
execute as @e[tag=olumkalp] at @s if entity @a[distance=..1] run effect give @a[distance=..1] minecraft:instant_health 1 3 true
execute as @e[tag=olumkalp] at @s if entity @a[distance=..1] run kill @s

execute as @e[tag=olumkalp] at @s positioned ~ ~1 ~ if entity @a[distance=..1] run playsound minecraft:block.decorated_pot.insert master @a[distance=..1] ~ ~ ~ 100 0
execute as @e[tag=olumkalp] at @s positioned ~ ~1 ~ if entity @a[distance=..1] run particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 1 5 force @a
execute as @e[tag=olumkalp] at @s positioned ~ ~1 ~ if entity @a[distance=..1] run effect give @a[distance=..1] minecraft:instant_health 1 3 true
execute as @e[tag=olumkalp] at @s positioned ~ ~1 ~ if entity @a[distance=..1] run kill @s
scoreboard players add @e[tag=olumkalp] cansure 1
execute as @e[tag=olumkalp] at @s if score @s cansure matches 100.. run kill @s


# oylama tick
execute unless score .basladi anaskor matches 1.. run function data:oylama/tick

#-- Oyundan Çıkma Tick --#
execute as @a[scores={cikma=1..}] at @s run function data:oyundan_cikma/tick




#-- Oylama Sayac --#
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches 2.. run scoreboard players set .basladi anaskor -1
execute if score .basladi anaskor matches -1 run clear @a carrot_on_a_stick{oyDamga:1b}
execute if score .basladi anaskor matches -1 run scoreboard players set .bssaniye anaskor 5
execute if score .basladi anaskor matches -1 run title @a title {    "color": "aqua", "bold":true,   "score": {        "name": ".bssaniye",        "objective": "anaskor"    }}
execute if score .basladi anaskor matches ..-1 run scoreboard players add .bstick anaskor 1
execute if score .basladi anaskor matches -1 run scoreboard players set .basladi anaskor -2
execute if score .bstick anaskor matches 20.. run scoreboard players remove .bssaniye anaskor 1
execute if score .bstick anaskor matches 20.. run title @a title {    "color": "aqua", "bold":true,   "score": {        "name": ".bssaniye",        "objective": "anaskor"    }}
execute if score .bstick anaskor matches 20.. run playsound minecraft:block.note_block.bell player @a ~ ~ ~ 100 1 1
execute if score .bstick anaskor matches 20.. run scoreboard players set .bstick anaskor 0
execute if score .basladi anaskor matches ..-2 if score .bssaniye anaskor matches ..0 run title @a title {"bold": true,"color": "green","translate": "basla.yazi","fallback":"START!"}
execute if score .basladi anaskor matches ..-2 if score .bssaniye anaskor matches ..0 run function data:paintball_baslat


#-- Oyuncu Sayısı 2 den Azsa --#
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches ..1 run tellraw @a {"bold": true,"color": "dark_red","translate": "en.az.2","fallback":"At least 2 people are required to start the game!!!"}
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches ..1 run clear @a
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches ..1 run function data:oylama/oylama_aleti_verme
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches ..1 run effect clear @a
execute if score .basladi anaskor matches 0 if score .hazirveren anaskor >= .oyuncusayisi anaskor if score .oyuncusayisi anaskor matches ..1 run scoreboard players set .hazirveren anaskor 0


# sıralama tick
execute if score .basladi anaskor matches 0 run function data:siralama/tick

execute as @a at @s run function data:dolap/formaver

#-- Sol Ele Silahı Almayı Engelleme --#
execute as @a[nbt={Inventory:[{Slot:-106b,id:"minecraft:crossbow",tag:{paintSilah:1b}}]}] at @s run function data:solel

#-- Link --#
execute as @e[type=minecraft:interaction,tag=link] at @s on target run tellraw @s  {"text":"CrafTea English Youtube Channel  ","color":"green","clickEvent":{"action":"open_url","value":"https://www.youtube.com/@CrafTeaEnglish"}}
execute as @e[type=minecraft:interaction,tag=link] at @s run data remove entity @s interaction


execute as @a[tag=!ilkgiris] at @s if score .basladi anaskor matches 0 run function data:ilkgiris/ilkgirisoylama
execute as @a[tag=!ilkgiris] at @s if score .basladi anaskor matches 1 run function data:ilkgiris/ilkgirisioyun 
