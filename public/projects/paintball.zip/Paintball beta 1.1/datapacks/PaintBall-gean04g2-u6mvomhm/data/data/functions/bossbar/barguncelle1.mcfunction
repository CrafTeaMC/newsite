# bossbarı değiştir
execute store result storage minecraft:bossbar barisim int 1 run scoreboard players get @s id
execute as @s at @s run function data:bossbar/barguncelle2 with storage minecraft:bossbar