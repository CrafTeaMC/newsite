execute as @a[scores={oldurme=0}] at @s run tp @s 495.93 71.98 506.35 1620.15 30
execute as @a[scores={oldurme=0}] at @s run tag @s add siralandi
function data:siralama/sirala