clear @s minecraft:carrot_on_a_stick{oyDamga:1b}

scoreboard players set @s oysagtik 0
tag @s add oyverdi
scoreboard players add .hazirveren anaskor 1
playsound minecraft:block.decorated_pot.insert master @s ~ ~ ~ 100 0 0.7
effect give @s minecraft:glowing infinite 255 true
item replace entity @s weapon.mainhand with minecraft:carrot_on_a_stick{CustomModelData:2,oyIptal:1b,oyDamga:1b,display:{Name:'[{"translate":"iptal.ver","color":"red","bold":true,"italic":false,"fallback":"CANCEL "},{"translate":"sag.tikla","color":"aqua","bold":false,"italic":true,"fallback":"(RIGHT CLICK)"}]'}}
