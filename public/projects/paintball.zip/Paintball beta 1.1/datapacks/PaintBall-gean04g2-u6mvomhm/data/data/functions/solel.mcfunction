clear @s crossbow{paintSilah:1b}
function data:paintball_silah_verme