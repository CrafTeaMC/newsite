execute as @a at @s run scoreboard players operation @s siralamakill = @s oldurme

scoreboard players set .bitis anaskor 0
gamemode adventure @a
scoreboard players set @a ssaniye 0
scoreboard players set @a stick 0
scoreboard players set .basladi anaskor 0
clear @a
title @s times 0t 3s 5t
schedule function data:paintball_oyunu_tamamen_bitir 15s
scoreboard players reset * siralama
function data:siralama/basla