execute as @a[nbt=!{Inventory:[{id:"minecraft:carrot_on_a_stick",tag:{oyVer:1b,oyDamga:1b}}]}] at @s run give @s minecraft:carrot_on_a_stick{CustomModelData:1,oyVer:1b,oyDamga:1b,display:{Name:'[{"translate":"hazir.ver","color":"green","bold":true,"italic":false,"fallback":"BE READY "},{"translate":"sag.tikla","color":"aqua","bold":false,"italic":true,"fallback":"(RIGHT CLICK)"}]'}}

