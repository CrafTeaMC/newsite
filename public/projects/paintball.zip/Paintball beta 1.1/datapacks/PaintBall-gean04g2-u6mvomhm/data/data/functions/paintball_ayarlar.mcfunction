scoreboard objectives add anaskor dummy
scoreboard objectives add sagtik minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add olum deathCount
scoreboard objectives add olum2 deathCount
scoreboard objectives add hazir dummy
scoreboard objectives add vurulmatest dummy
scoreboard objectives add stick dummy
scoreboard objectives add ssaniye dummy
scoreboard objectives add oldurme playerKillCount
scoreboard objectives add oldurme2 playerKillCount
scoreboard objectives add id dummy
scoreboard objectives add fbomba dummy
scoreboard objectives add ebomba dummy
scoreboard objectives add cansure dummy
scoreboard objectives add teacoin dummy
scoreboard objectives add siralamakill dummy
execute as @a at @s run function data:bossbar/barguncelle1
gamerule keepInventory true
effect give @a night_vision infinite 255 true
gamerule sendCommandFeedback false
gamerule showDeathMessages false
gamerule doImmediateRespawn true
gamerule doDaylightCycle false
gamerule doWeatherCycle false
difficulty peaceful
gamerule fallDamage false
time set day
weather clear
function data:paintball_skor_sifirlama
scoreboard objectives add endergoz minecraft.used:minecraft.ender_eye
scoreboard objectives add mermiid dummy
scoreboard objectives add siralama dummy
scoreboard objectives add barolustu dummy
scoreboard players set @a unknow 0
execute as @a at @s run function data:dolap/formaver