tp @s 573 82 530
clear @s
function data:paintball_silah_verme
scoreboard players add @s olum2 1
tag @s add ilkgiris