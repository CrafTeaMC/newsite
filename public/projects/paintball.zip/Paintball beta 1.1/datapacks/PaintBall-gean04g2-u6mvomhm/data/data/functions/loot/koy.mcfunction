spreadplayers 9 8 18 18 true @e[limit=1,tag=lootmarker]
execute as @e[tag=lootmarker] at @s run summon minecraft:item_display ~ ~-2 ~ {Tags:["lootvarilmarker"],Passengers:[{id:"minecraft:block_display",block_state:{Name:"minecraft:barrel"},Tags:["lootvarildisplay"],transformation:[1.0000f,0.0000f,0.0000f,-0.5000f,0.0000f,1.0000f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f,-0.5000f,0.0000f,0.0000f,0.0000f,1.0000f]}]}
execute store result score .lootrandom anaskor run random value 1..10
