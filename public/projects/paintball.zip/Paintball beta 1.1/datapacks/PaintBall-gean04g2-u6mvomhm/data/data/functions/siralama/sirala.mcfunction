scoreboard players set $max oldurme -1000
scoreboard players operation $max oldurme > @a oldurme
execute as @a at @s if score @s oldurme = $max oldurme run tag @s add gecicienyuksek
execute as @a[tag=gecicienyuksek,limit=1] at @s run function data:siralama/sirala2




