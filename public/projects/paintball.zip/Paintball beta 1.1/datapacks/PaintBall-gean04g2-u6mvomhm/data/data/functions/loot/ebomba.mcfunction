execute store result score @s ebomba on origin run scoreboard players get @s id


summon minecraft:marker ~ ~ ~ {Tags:["ebomba","ebomba1"]}
ride @e[limit=1,tag=ebomba1,sort=nearest] mount @s
execute on passengers run tag @s remove ebomba1
execute on passengers store result score @s ebomba on vehicle run scoreboard players get @s ebomba