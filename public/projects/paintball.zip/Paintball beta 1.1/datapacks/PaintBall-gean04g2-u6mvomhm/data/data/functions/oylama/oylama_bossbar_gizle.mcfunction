bossbar set minecraft:oylama players
scoreboard players set @a hazir 0
scoreboard players set .oylama anaskor 0