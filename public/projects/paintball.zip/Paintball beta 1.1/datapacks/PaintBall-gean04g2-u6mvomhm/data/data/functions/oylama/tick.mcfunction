#--  Bossbar
execute store result score .oyuncusayisi anaskor if entity @a
bossbar set minecraft:oylama name [{"translate":"oylama.bar","color":"blue","bold":true,"fallback":"Everyone's expected to be ready.. "},{"score":{"name":".hazirveren","objective":"anaskor"},"color":"green","bold":true},{"text":"/","color":"gold","bold":true},{"score":{"name":".oyuncusayisi","objective":"anaskor"},"color":"dark_green","bold":true}]

# sol el
execute as @a[nbt={Inventory:[{id:"minecraft:carrot_on_a_stick",Slot:-106b,Count:1b,tag:{oyIptal:1b}}]}] at @s run function data:oylama/solel1
execute as @a[nbt={Inventory:[{id:"minecraft:carrot_on_a_stick",Slot:-106b,Count:1b,tag:{oyVer:1b}}]}] at @s run function data:oylama/solel2

# oy verme
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{oyVer:1b}}},scores={oysagtik=1..}] at @s run function data:oylama/oyverdi
execute as @a[nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{oyIptal:1b}}},scores={oysagtik=1..}] at @s run function data:oylama/oyiptal

# çıkan olursa sil
execute if score .hazirveren anaskor > .oyuncusayisi anaskor run function data:oylama/oyiptal
execute store result score .oyundakihazirveren anaskor if entity @a[tag=oyverdi]
execute if score .hazirveren anaskor > .oyundakihazirveren anaskor run function data:oylama/oyiptal
execute if score .hazirveren anaskor matches ..-1 run scoreboard players set .hazirveren anaskor 0
