execute as @a at @s run function data:dogum
