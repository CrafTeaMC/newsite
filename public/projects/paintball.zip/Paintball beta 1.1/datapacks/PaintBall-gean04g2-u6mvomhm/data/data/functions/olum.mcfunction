execute as @e[tag=spectate,scores={olum2=1..}] at @s run gamemode spectator
execute as @e[tag=spectate,scores={olum2=1..}] at @s run tp @s 20 22 5
execute as @e[tag=spectate,scores={olum2=1..}] at @s run scoreboard players set @s ssaniye 3

