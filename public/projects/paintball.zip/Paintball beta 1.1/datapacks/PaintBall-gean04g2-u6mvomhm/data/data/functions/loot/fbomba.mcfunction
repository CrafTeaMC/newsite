scoreboard players set @s fbomba 1
summon minecraft:area_effect_cloud ~ ~ ~ {Tags:["fbomba","fbomba1"],Duration:99999}
ride @e[limit=1,tag=fbomba1,sort=nearest] mount @s
execute on passengers run tag @s remove fbomba1