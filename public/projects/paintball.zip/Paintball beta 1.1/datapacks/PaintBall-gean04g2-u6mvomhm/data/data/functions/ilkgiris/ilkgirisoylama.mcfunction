function data:oylama/oylama_bossbar_gosterme
execute as @a at @s run function data:bossbar/barguncelle1
effect clear @s
tp @s 573 82 530
team join baslangic @s
clear @s
gamemode adventure @s
function data:oylama/oylama_aleti_verme
tag @s add ilkgiris