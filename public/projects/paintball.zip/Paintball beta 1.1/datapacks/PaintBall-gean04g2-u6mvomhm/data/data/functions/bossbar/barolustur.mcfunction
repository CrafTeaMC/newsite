scoreboard players set @s barolustu 1
execute unless score @s id = @s id store result score @s id run scoreboard players add #idSayisi id 1
execute store result storage minecraft:bossbar oyuncusayisi int 1 run scoreboard players get #idSayisi id
execute as @s at @s run function data:bossbar/barolustur2 with storage minecraft:bossbar