item replace entity @s weapon.offhand with air
give @s minecraft:carrot_on_a_stick{CustomModelData:2,oyIptal:1b,oyDamga:1b,display:{Name:'[{"translate":"iptal.ver","color":"red","bold":true,"italic":false,"fallback":"CANCEL "},{"translate":"sag.tikla","color":"aqua","bold":false,"italic":true,"fallback":"(RIGHT CLICK)"}]'}}

