
$bossbar set $(barisim) name [{"text":"\u2694 ","bold":true,"color":"dark_gray"},{"score":{"name":"@s","objective":"oldurme"},"bold":true,"color":"dark_green"},{"translate":"oldurme.yazi","bold":true,"color":"dark_purple","fallback":" Kill "},{"text":"| ","bold":true,"color":"dark_blue"},{"text":"\u2620 ","bold":true,"color":"gray"},{"score":{"name":"@s","objective":"olum"},"bold":true,"color":"yellow"},{"translate":"olme.yazi","bold":true,"color":"dark_red","fallback":" Death "}]
$execute if score .basladi anaskor matches 1.. run bossbar set $(barisim) visible true
$execute if score .basladi anaskor matches 1.. run bossbar set $(barisim) players @s
$execute if score .basladi anaskor matches 0 run bossbar set $(barisim) visible false

scoreboard players set .barguncelle anaskor 0