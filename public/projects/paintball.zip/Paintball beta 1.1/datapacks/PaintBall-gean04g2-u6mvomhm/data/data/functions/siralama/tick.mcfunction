data merge entity @e[limit=1,tag=3isimtext] {text:'{"selector":"@a[scores={siralama=3}]","color":"#8C2929","bold":true}',background:16711680}
data merge entity @e[limit=1,tag=2isimtext] {text:'{"selector":"@a[scores={siralama=2}]","color":"#C2B436","bold":true}',background:16711680}
data merge entity @e[limit=1,tag=1isimtext] {text:'{"selector":"@a[scores={siralama=1}]","color":"#E7A5F7","bold":true}',background:16711680}

#-- Oturma --#
execute as @e[type=minecraft:interaction,tag=bankint] at @s on target run ride @s mount @e[limit=1,tag=bankint,sort=nearest]
execute as @e[type=minecraft:interaction,tag=bankint] at @s run data remove entity @s interaction

#-- Hasan Karga Karga Gak Dedi --#
execute as @e[tag=kargadisplay] at @s run tp @s ~ ~ ~ facing entity @p
execute as @e[tag=kargadisplay] at @s run tp @s ~ ~ ~ ~ 0



# custom süre
data merge entity @e[limit=1,tag=lobisuretext2] {text:'{"score":{"name":".scustomdakika","objective":"anaskor"},"color":"dark_blue","bold":true}',background:4756704}
execute as @e[type=minecraft:interaction,tag=lobisureint1] at @s on target run scoreboard players add .scustomdakika anaskor 1
execute as @e[type=minecraft:interaction,tag=lobisureint2] at @s on target run scoreboard players remove .scustomdakika anaskor 1
execute as @e[type=minecraft:interaction,tag=lobisureint] at @s on target run playsound minecraft:block.note_block.xylophone master @s ~ ~ ~ 100 0

execute if score .scustomdakika anaskor matches ..0 run tellraw @a {"translate":"sure.yazi2","color":"red","fallback":"TIME MUST BE AT LEAST 1 MINUTE!"}
execute if score .scustomdakika anaskor matches ..0 run playsound minecraft:block.note_block.bass master @a ~ ~ ~ 100 1
execute if score .scustomdakika anaskor matches ..0 run scoreboard players set .scustomdakika anaskor 1


execute as @e[type=minecraft:interaction,tag=lobisureint] at @s run data remove entity @s interaction


#Yazı ve efekt
title @a actionbar {"translate":"surum.yazi","color":"green","bold":true,"fallback":"V E R S I O N: 1.20.4"}
effect give @a minecraft:resistance 1 255 true
effect give @a minecraft:saturation 1 255 true