scoreboard players set @s cekissayac 0
item replace entity @s weapon.mainhand with crossbow{CustomModelData:1,display:{Name:'{"translate":"silah.isim","color":"aqua","bold":true,"italic":false,"fallback":"Paintball Gun"}'},Charged:1,ChargedProjectiles:[{id:"minecraft:arrow",Count:1b}],paintSilah:1b}
