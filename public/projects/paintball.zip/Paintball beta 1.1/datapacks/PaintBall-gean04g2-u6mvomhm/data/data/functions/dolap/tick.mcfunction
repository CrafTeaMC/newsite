# göğüslük
execute as @e[type=minecraft:interaction,tag=dolapgmaviint] at @s on target run scoreboard players set @s gogusluk 4
execute as @e[type=minecraft:interaction,tag=dolapgpembeint] at @s on target run scoreboard players set @s gogusluk 3
execute as @e[type=minecraft:interaction,tag=dolapgkirmiziint] at @s on target run scoreboard players set @s gogusluk 2
execute as @e[type=minecraft:interaction,tag=dolapgsiyahint] at @s on target run scoreboard players set @s gogusluk 1
execute as @e[type=minecraft:interaction,tag=dolapgamaviint] at @s on target run scoreboard players set @s gogusluk 5

# kafalık
execute as @e[type=minecraft:interaction,tag=dolapkmaviint] at @s on target run scoreboard players set @s kafa 4
execute as @e[type=minecraft:interaction,tag=dolapkpembeint] at @s on target run scoreboard players set @s kafa 3
execute as @e[type=minecraft:interaction,tag=dolapkkirmiziint] at @s on target run scoreboard players set @s kafa 2
execute as @e[type=minecraft:interaction,tag=dolapksiyahint] at @s on target run scoreboard players set @s kafa 1
execute as @e[type=minecraft:interaction,tag=dolapkamaviint] at @s on target run scoreboard players set @s kafa 5

# pantalon
execute as @e[type=minecraft:interaction,tag=dolappmaviint] at @s on target run scoreboard players set @s pantolon 4
execute as @e[type=minecraft:interaction,tag=dolapppembeint] at @s on target run scoreboard players set @s pantolon 3
execute as @e[type=minecraft:interaction,tag=dolappkirmiziint] at @s on target run scoreboard players set @s pantolon 2
execute as @e[type=minecraft:interaction,tag=dolappsiyahint] at @s on target run scoreboard players set @s pantolon 1
execute as @e[type=minecraft:interaction,tag=dolappamaviint] at @s on target run scoreboard players set @s pantolon 5

# bot
execute as @e[type=minecraft:interaction,tag=dolapbmaviint] at @s on target run scoreboard players set @s bot 4
execute as @e[type=minecraft:interaction,tag=dolapbpembeint] at @s on target run scoreboard players set @s bot 3
execute as @e[type=minecraft:interaction,tag=dolapbkirmiziint] at @s on target run scoreboard players set @s bot 2
execute as @e[type=minecraft:interaction,tag=dolapbsiyahint] at @s on target run scoreboard players set @s bot 1
execute as @e[type=minecraft:interaction,tag=dolapbamaviint] at @s on target run scoreboard players set @s bot 5


# renksiz
execute as @e[type=minecraft:interaction,tag=dolapbrenksizint] at @s on target run scoreboard players set @s bot 0
execute as @e[type=minecraft:interaction,tag=dolapprenksizint] at @s on target run scoreboard players set @s pantolon 0
execute as @e[type=minecraft:interaction,tag=dolapkrenksizint] at @s on target run scoreboard players set @s kafa 0
execute as @e[type=minecraft:interaction,tag=dolapgrenksizint] at @s on target run scoreboard players set @s gogusluk 0

# formayı giydir
execute as @e[type=minecraft:interaction,tag=dolapint] at @s on target run function data:dolap/formaver

# ışınlanma
particle minecraft:nautilus 29.99 101.00 405.00 0.5 2 0.5 1 5 normal @a
execute as @a[x=29,y=101,z=405,dx=1,dy=2,dz=-1,] at @s run particle minecraft:shriek 0 ~ ~ ~ 0.5 0.5 0.5 1 0 force @a
execute as @a[x=29,y=101,z=405,dx=1,dy=2,dz=-1,] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 100 0
execute as @a[x=29,y=101,z=405,dx=1,dy=2,dz=-1,] at @s run tp @s 573 82 530

particle minecraft:nautilus 589.23 81 529.89 1 1 1 1 2 normal @a
particle minecraft:portal 589.23 81 529.89 1 1 1 1 2 normal @a
execute as @a[x=589,y=80,z=531,dx=-1,dy=2,dz=-2,] at @s run particle minecraft:shriek 0 ~ ~ ~ 0.5 0.5 0.5 1 0 force @a
execute as @a[x=589,y=80,z=531,dx=-1,dy=2,dz=-2,] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 100 0
execute as @a[x=589,y=80,z=531,dx=-1,dy=2,dz=-2,] at @s run tp @s 34.59 102.42 405.34







# sıfırla
execute as @e[type=minecraft:interaction,tag=dolapint] at @s run data remove entity @s interaction

