scoreboard players set .scustomdakika anaskor 8
function data:paintball_ayarlar