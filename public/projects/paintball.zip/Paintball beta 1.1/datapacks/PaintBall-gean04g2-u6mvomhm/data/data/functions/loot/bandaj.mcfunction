effect give @s minecraft:instant_health 1 1 true
playsound minecraft:item.book.page_turn master @s ~ ~ ~ 100 2 0.3
title @s actionbar {"text":"BANDAJ SARILDI!","color":"green","bold":true}
scoreboard players set @s endergoz 0
kill @e[type=eye_of_ender,limit=1]
stopsound @a * minecraft:entity.ender_eye.launch