tp @a 573 82 530
gamemode adventure @a 
team add baslangic
kill @e[tag=lootvarilmarker]
kill @e[tag=lootvarildisplay]
kill @e[tag=lootitem]
team modify baslangic friendlyFire false
team join baslangic @a
clear @a
function data:paintball_skor_sifirlama
execute as @a at @s run function data:bossbar/barguncelle1
function data:oylama/oylama_bossbar_gosterme
scoreboard objectives setdisplay list
function data:oylama/oylama_aleti_verme
scoreboard players reset * oldurme
scoreboard players set @a oldurme 0
effect clear @a
scoreboard players reset * siralama
scoreboard players set .siralamabitir anaskor 0