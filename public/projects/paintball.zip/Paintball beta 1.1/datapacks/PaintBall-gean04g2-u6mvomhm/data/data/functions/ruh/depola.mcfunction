execute store result storage minecraft:anadepo olx int 1 run data get entity @s LastDeathLocation.pos[0]
execute store result storage minecraft:anadepo oly int 1 run data get entity @s LastDeathLocation.pos[1]
execute store result storage minecraft:anadepo olz int 1 run data get entity @s LastDeathLocation.pos[2]
function data:ruh/particle with storage minecraft:anadepo