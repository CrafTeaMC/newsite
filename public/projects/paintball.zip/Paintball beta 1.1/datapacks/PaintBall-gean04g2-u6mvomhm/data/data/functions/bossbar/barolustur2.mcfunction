scoreboard players set @s oldurme 0
scoreboard players set @s olum 0

$bossbar add $(oyuncusayisi) [{"text":"\u2694 ","bold":true,"color":"dark_gray"},{"score":{"name":"@s","objective":"oldurme"},"bold":true,"color":"dark_green"},{"translate":"oldurme.yazi","bold":true,"color":"dark_purple","fallback":" Kill "},{"text":"| ","bold":true,"color":"dark_blue"},{"text":"\u2620 ","bold":true,"color":"gray"},{"score":{"name":"@s","objective":"olum"},"bold":true,"color":"yellow"},{"translate":"olme.yazi","bold":true,"color":"dark_red","fallback":" Death "}]
$bossbar set $(oyuncusayisi) players @s
$bossbar set $(oyuncusayisi) color blue
$bossbar set $(oyuncusayisi) style progress
$bossbar set $(oyuncusayisi) max 1
$bossbar set $(oyuncusayisi) value 0
scoreboard players set .barolusturuyor anaskor 0

