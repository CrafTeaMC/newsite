tag @s add ebomba2
execute as @a at @s if score @s id = @e[limit=1,tag=ebomba2] ebomba run tag @s add ebombaatan
execute as @a[distance=..5] at @s run damage @s 12 minecraft:arrow by @a[limit=1,tag=ebombaatan]
tag @a remove ebombaatan
particle minecraft:gust ~ ~ ~ 2 2 2 1 20 force @a
particle minecraft:explosion ~ ~ ~ 2 2 2 1 20 force @a
particle minecraft:campfire_signal_smoke ~ ~ ~ 2 2 2 1 20 force @a
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 2 2
playsound minecraft:entity.breeze.jump master @a ~ ~ ~ 2 2
tp @e[type=minecraft:chicken] ~ ~-500 ~
kill @s
