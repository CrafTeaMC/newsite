#-- Oyundan Çıkma --#
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run function data:oylama/oylama_bossbar_gosterme
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run effect clear @s
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run tp @s 573 82 530
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run team join baslangic @s
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run clear @s
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run gamemode adventure @s
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run function data:oylama/oylama_aleti_verme
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 0 run tag @s remove oyverdi




execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 1.. run tp @s 573 82 530
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 1.. run clear @s
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 1.. run function data:paintball_silah_verme
execute as @a[scores={cikma=1..}] at @s if score .basladi anaskor matches 1.. run scoreboard players add @s olum2 1
execute as @a[scores={cikma=1..}] at @s run scoreboard players set @s cikma 0

