scoreboard players set .sdakika anaskor 0
scoreboard players set .ssaniye anaskor 0
scoreboard players set .stick anaskor 0
scoreboard players set .basladi anaskor 0
scoreboard players set .bitis anaskor 0
scoreboard players set .hit vurulmatest 0
scoreboard players set .encokolen anaskor 0
tag @a remove birinci
tag @a remove encokolen
tag @a remove spectate
scoreboard players set .distance vurulmatest 0
scoreboard players set .hazirveren anaskor 0
#scoreboard players set @a kafa 0
#scoreboard players set @a gogusluk 0
#scoreboard players set @a pantolon 0
#scoreboard players set @a bot 0
scoreboard players set @a yasam 1
scoreboard players set @a olum 0
scoreboard players set @a olum2 0
scoreboard players set @a ssaniye 0
scoreboard players set @a stick 0
scoreboard players set @a oldurme2 0
scoreboard players set @a hazir 0
scoreboard players set .olumtavan olum -2147483648
scoreboard players set .basladi anaskor 0
gamerule announceAdvancements false
execute as @a at @s run function data:bossbar/barguncelle1

