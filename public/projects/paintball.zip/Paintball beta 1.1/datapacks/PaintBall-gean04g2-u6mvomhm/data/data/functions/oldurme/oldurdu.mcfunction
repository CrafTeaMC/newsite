scoreboard players set @s oldurme2 0
execute store result score .oldursesrandom anaskor run random value 1..5

#execute if score .oldursesrandom anaskor matches 1 run playsound minecraft:olum.1 master @s
execute if score .oldursesrandom anaskor matches 1 run title @s actionbar {"translate":"oldurme.yazi1","color":"green","fallback":"Well Done!"}

#execute if score .oldursesrandom anaskor matches 2 run playsound minecraft:olum.2 master @s
execute if score .oldursesrandom anaskor matches 2 run title @s actionbar {"translate":"oldurme.yazi2","color":"green","fallback":"Good Job!"}

#execute if score .oldursesrandom anaskor matches 3 run playsound minecraft:olum.3 master @s
execute if score .oldursesrandom anaskor matches 3 run title @s actionbar {"translate":"oldurme.yazi3","color":"green","fallback":"You Beat Him!"}

#execute if score .oldursesrandom anaskor matches 4 run playsound minecraft:olum.4 master @s
execute if score .oldursesrandom anaskor matches 4 run title @s actionbar {"translate":"oldurme.yazi4","color":"green","fallback":"You are cool!"}

#execute if score .oldursesrandom anaskor matches 5 run playsound minecraft:olum.5 master @s
execute if score .oldursesrandom anaskor matches 5 run title @s actionbar {"translate":"oldurme.yazi5","color":"green","fallback":"Keep it up!"}