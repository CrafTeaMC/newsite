execute store result score @s siralama run scoreboard players add $max siralama 1
scoreboard players reset @s oldurme
tag @s remove gecicienyuksek
tag @s add siralandi


execute store result score .siralanmayansayisi anaskor if entity @a[tag=!siralandi]

execute if score .siralanmayansayisi anaskor matches 1.. run function data:siralama/sirala
execute if score .siralanmayansayisi anaskor matches 0 unless score .siralamabitir anaskor matches 1.. run function data:siralama/bitir
