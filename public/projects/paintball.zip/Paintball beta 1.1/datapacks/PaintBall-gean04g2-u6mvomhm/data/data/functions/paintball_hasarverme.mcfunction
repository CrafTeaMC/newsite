damage @e[tag=vurulan,limit=1,type=player,sort=nearest] 14 minecraft:player_attack by @e[tag=vuran,limit=1,type=player,sort=nearest]
execute as @e[tag=vurulan,limit=1,type=player,sort=nearest] at @s run tag @s remove vurulan
execute as @e[tag=vuran,limit=1,type=player,sort=nearest] at @s run tag @s remove vuran