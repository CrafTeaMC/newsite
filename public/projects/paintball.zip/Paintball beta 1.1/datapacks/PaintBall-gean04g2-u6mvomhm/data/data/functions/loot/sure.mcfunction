



execute if score .basladi anaskor matches 1.. run function data:loot/koy
execute if score .basladi anaskor matches 1.. run schedule function data:loot/sure 15s