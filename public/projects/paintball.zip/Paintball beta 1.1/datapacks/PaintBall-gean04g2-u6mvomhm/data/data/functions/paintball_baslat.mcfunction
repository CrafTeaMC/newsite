tp @a 20 22 5

function data:oylama/oylama_bossbar_gizle
tag @a remove oyverdi
function data:paintball_skor_sifirlama
function data:paintball_silah_verme
scoreboard players set .basladi anaskor 1
scoreboard players set .bssaniye anaskor 0
scoreboard players set .bstick anaskor 0
team modify baslangic friendlyFire true
gamemode adventure @a
effect clear @a minecraft:glowing
function data:loot/sure
execute as @a at @s run function data:bossbar/barguncelle1
scoreboard objectives setdisplay list oldurme
scoreboard players set @a oldurme 0
tag @a remove gecicienyuksek
schedule function data:ilkbasdogum 20t