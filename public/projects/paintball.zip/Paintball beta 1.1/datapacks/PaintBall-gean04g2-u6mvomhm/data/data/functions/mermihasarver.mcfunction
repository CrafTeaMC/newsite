tag @s add mermimarker2
execute as @a at @s if score @s id = @e[limit=1,tag=mermimarker2] mermiid run tag @s add mermiatan
damage @p[tag=!mermiatan] 15 minecraft:player_attack by @a[limit=1,tag=mermiatan]
tag @a remove mermiatan
kill @s