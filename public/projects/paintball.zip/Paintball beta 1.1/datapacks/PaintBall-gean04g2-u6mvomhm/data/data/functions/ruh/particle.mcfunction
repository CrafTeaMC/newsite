$execute positioned $(olx) $(oly) $(olz) run particle minecraft:soul ~ ~1 ~ 0.5 1 0.5 0 10 force @a
$execute positioned $(olx) $(oly) $(olz) run particle minecraft:sculk_soul ~ ~1 ~ 0.5 1 0.5 0 10 force @a

$summon text_display $(olx) $(oly) $(olz) {billboard:"vertical",Tags:["olumkalp"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1f,0f],scale:[5f,5f,5f]},text:'{"text":"❤","color":"dark_red"}',background:16711680}
