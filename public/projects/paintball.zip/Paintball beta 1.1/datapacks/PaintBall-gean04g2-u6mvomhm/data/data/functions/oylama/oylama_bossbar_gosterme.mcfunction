bossbar add oylama "Oylama"
bossbar set minecraft:oylama players @a
bossbar set minecraft:oylama color blue