#-- Kafalar --#
execute as @s at @s unless score @s kafa matches 1.. run item replace entity @s armor.head with minecraft:leather_helmet{oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={kafa=1}] at @s run item replace entity @s armor.head with minecraft:leather_helmet{display:{color:2435112},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={kafa=2}] at @s run item replace entity @s armor.head with minecraft:leather_helmet{display:{color:13576992},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={kafa=3}] at @s run item replace entity @s armor.head with minecraft:leather_helmet{display:{color:13574345},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={kafa=4}] at @s run item replace entity @s armor.head with minecraft:leather_helmet{display:{color:3547343},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={kafa=5}] at @s run item replace entity @s armor.head with minecraft:leather_helmet{display:{color:2150349},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}

#-- Göğüslükler --#
execute as @s at @s unless score @s gogusluk matches 1.. run item replace entity @s armor.chest with minecraft:leather_chestplate{oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={gogusluk=1}] at @s run item replace entity @s armor.chest with minecraft:leather_chestplate{display:{color:2435112},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={gogusluk=2}] at @s run item replace entity @s armor.chest with minecraft:leather_chestplate{display:{color:13576992},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={gogusluk=3}] at @s run item replace entity @s armor.chest with minecraft:leather_chestplate{display:{color:13574345},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={gogusluk=4}] at @s run item replace entity @s armor.chest with minecraft:leather_chestplate{display:{color:3547343},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={gogusluk=5}] at @s run item replace entity @s armor.chest with minecraft:leather_chestplate{display:{color:2150349},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}

#-- Pantolonlar --#
execute as @s at @s unless score @s pantolon matches 1.. run item replace entity @s armor.legs with minecraft:leather_leggings{oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={pantolon=1}] at @s run item replace entity @s armor.legs with minecraft:leather_leggings{display:{color:2435112},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={pantolon=2}] at @s run item replace entity @s armor.legs with minecraft:leather_leggings{display:{color:13576992},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={pantolon=3}] at @s run item replace entity @s armor.legs with minecraft:leather_leggings{display:{color:13574345},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={pantolon=4}] at @s run item replace entity @s armor.legs with minecraft:leather_leggings{display:{color:3547343},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={pantolon=5}] at @s run item replace entity @s armor.legs with minecraft:leather_leggings{display:{color:2150349},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]} 

#-- Botlar --#
execute as @s at @s unless score @s bot matches 1.. run item replace entity @s armor.feet with minecraft:leather_boots{oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={bot=1}] at @s run item replace entity @s armor.feet with minecraft:leather_boots{display:{color:2435112},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={bot=2}] at @s run item replace entity @s armor.feet with minecraft:leather_boots{display:{color:13576992},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={bot=3}] at @s run item replace entity @s armor.feet with minecraft:leather_boots{display:{color:13574345},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={bot=4}] at @s run item replace entity @s armor.feet with minecraft:leather_boots{display:{color:3547343},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}
execute as @s[scores={bot=5}] at @s run item replace entity @s armor.feet with minecraft:leather_boots{display:{color:2150349},oyunzirh:1b,HideFlags:255,Unbreakable:1b,Enchantments:[{id:"minecraft:binding_curse",lvl:1s}]}

