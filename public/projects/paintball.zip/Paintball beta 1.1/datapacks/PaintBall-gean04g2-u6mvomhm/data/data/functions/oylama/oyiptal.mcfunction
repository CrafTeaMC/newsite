clear @s minecraft:carrot_on_a_stick{oyDamga:1b}
scoreboard players set @s oysagtik 0
tag @s remove oyverdi
scoreboard players remove .hazirveren anaskor 1
playsound minecraft:block.decorated_pot.insert_fail master @s ~ ~ ~ 100 1 0.4
effect clear @s minecraft:glowing
item replace entity @s weapon.mainhand with minecraft:carrot_on_a_stick{CustomModelData:1,oyVer:1b,oyDamga:1b,display:{Name:'[{"translate":"hazir.ver","color":"green","bold":true,"italic":false,"fallback":"BE READY "},{"translate":"sag.tikla","color":"aqua","bold":false,"italic":true,"fallback":"(RIGHT CLICK)"}]'}}
